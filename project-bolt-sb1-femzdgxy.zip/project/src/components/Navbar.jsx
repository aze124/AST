import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';

function Navbar() {
  const location = useLocation();

  return (
    <nav className="fixed w-full bg-black/80 backdrop-blur-sm border-b border-white/10 z-50 shadow-[0_0_15px_rgba(255,255,255,0.1)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-white via-white to-gray-300 text-transparent bg-clip-text glow">
              AST-1
            </span>
          </Link>
          
          <div className="flex space-x-8">
            <Link
              to="/"
              className={`relative ${
                location.pathname === '/' ? 'text-white glow' : 'text-gray-300'
              } hover:text-white transition-colors`}
            >
              {location.pathname === '/' && (
                <motion.div
                  layoutId="navbar-underline"
                  className="absolute left-0 right-0 h-0.5 -bottom-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                />
              )}
              Introduction
            </Link>
            
            <Link
              to="/universal-ai"
              className={`relative ${
                location.pathname === '/universal-ai' ? 'text-white glow' : 'text-gray-300'
              } hover:text-white transition-colors`}
            >
              {location.pathname === '/universal-ai' && (
                <motion.div
                  layoutId="navbar-underline"
                  className="absolute left-0 right-0 h-0.5 -bottom-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                />
              )}
              Universal AI
            </Link>

            <Link
              to="/chat"
              className={`relative ${
                location.pathname === '/chat' ? 'text-white glow' : 'text-gray-300'
              } hover:text-white transition-colors`}
            >
              {location.pathname === '/chat' && (
                <motion.div
                  layoutId="navbar-underline"
                  className="absolute left-0 right-0 h-0.5 -bottom-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                />
              )}
              Chat
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;