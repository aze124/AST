import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Introduction from './pages/Introduction';
import UniversalAI from './pages/UniversalAI';
import NormalConversation from './pages/NormalConversation';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<Introduction />} />
          <Route path="/universal-ai" element={<UniversalAI />} />
          <Route path="/chat" element={<NormalConversation />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;