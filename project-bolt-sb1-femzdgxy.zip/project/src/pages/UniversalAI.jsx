import { motion } from 'framer-motion';
import { FaSearch, FaBrain, FaCode, FaBolt } from 'react-icons/fa';

function UniversalAI() {
  return (
    <div className="pt-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16"
      >
        <div className="text-center mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold mb-6 bg-gradient-to-r from-white via-gray-200 to-gray-400 text-transparent bg-clip-text"
          >
            Universal AI Features
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-400 max-w-3xl mx-auto"
          >
            Experience the power of advanced artificial intelligence with our comprehensive suite of features
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm"
          >
            <div className="flex items-center mb-6">
              <FaSearch className="text-3xl mr-4 text-blue-400" />
              <h2 className="text-2xl font-semibold">Advanced Research</h2>
            </div>
            <p className="text-gray-400">
              Conduct comprehensive research across multiple domains with our AI's powerful analytical capabilities.
              Get detailed insights and accurate information instantly.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm"
          >
            <div className="flex items-center mb-6">
              <FaBolt className="text-3xl mr-4 text-yellow-400" />
              <h2 className="text-2xl font-semibold">Instant Responses</h2>
            </div>
            <p className="text-gray-400">
              Experience lightning-fast response times with our optimized AI system.
              Get immediate answers to your queries without compromising on accuracy.
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm mb-16"
        >
          <div className="flex items-center mb-6">
            <FaCode className="text-3xl mr-4 text-green-400" />
            <h2 className="text-2xl font-semibold">DEX Workspace Analyzer</h2>
          </div>
          <p className="text-gray-400 mb-6">
            Our advanced DEX workspace analyzer provides deep insights into Roblox games:
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Script Analysis</h3>
              <p className="text-gray-400">
                Deep analysis of game scripts and their functionalities
              </p>
            </div>
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Security Scanning</h3>
              <p className="text-gray-400">
                Identify vulnerabilities and potential exploit points
              </p>
            </div>
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Performance Metrics</h3>
              <p className="text-gray-400">
                Analyze game performance and optimization opportunities
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="text-center"
        >
          <div className="flex items-center justify-center mb-8">
            <FaBrain className="text-4xl mr-4 text-purple-400" />
            <h2 className="text-3xl font-semibold">AI Integration</h2>
          </div>
          <p className="text-gray-400 max-w-3xl mx-auto mb-8">
            AST-1's Universal AI features seamlessly integrate with its core functionalities,
            creating a powerful ecosystem for development and analysis.
          </p>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Smart Learning</h3>
              <p className="text-gray-400">
                Continuously adapts and improves based on user interactions and feedback
              </p>
            </div>
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Contextual Understanding</h3>
              <p className="text-gray-400">
                Maintains context across conversations for more accurate and relevant responses
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}

export default UniversalAI;