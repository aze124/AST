import { motion } from 'framer-motion';
import { DiPython, DiJava } from 'react-icons/di';
import { SiRoblox, SiLua } from 'react-icons/si';

function Introduction() {
  return (
    <div className="pt-16 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16"
      >
        <div className="text-center mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold mb-6 bg-gradient-to-r from-white via-gray-200 to-gray-400 text-transparent bg-clip-text"
          >
            Meet AST-1
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-400 max-w-3xl mx-auto"
          >
            Your advanced AI companion for Roblox exploits and programming assistance
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors"
          >
            <h2 className="text-2xl font-semibold mb-4">Created by Experts</h2>
            <p className="text-gray-400">
              Developed by the talented duo of <span className="text-white">Iz9vs2k</span> and{" "}
              <span className="text-white">Chun</span>, AST-1 represents the cutting edge in AI-powered
              exploit development and coding assistance.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors"
          >
            <h2 className="text-2xl font-semibold mb-4">Powerful Capabilities</h2>
            <p className="text-gray-400">
              From generating sophisticated Roblox exploits to providing intelligent coding solutions,
              AST-1 is your ultimate programming companion.
            </p>
          </motion.div>
        </div>

        <div className="bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm mb-16">
          <h2 className="text-2xl font-semibold mb-6">Supported Languages</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center">
              <SiLua className="text-6xl mb-4 text-blue-400" />
              <span>Lua</span>
            </div>
            <div className="flex flex-col items-center">
              <DiPython className="text-6xl mb-4 text-green-400" />
              <span>Python</span>
            </div>
            <div className="flex flex-col items-center">
              <DiJava className="text-6xl mb-4 text-orange-400" />
              <span>Java</span>
            </div>
            <div className="flex flex-col items-center">
              <SiRoblox className="text-6xl mb-4 text-red-400" />
              <span>Roblox</span>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <h2 className="text-3xl font-semibold mb-6">Why Choose AST-1?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Advanced Exploit Generation</h3>
              <p className="text-gray-400">
                Specialized in creating sophisticated Roblox exploits with intelligent optimization
              </p>
            </div>
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Natural Conversations</h3>
              <p className="text-gray-400">
                Engage in fluid, context-aware discussions about programming and exploits
              </p>
            </div>
            <div className="bg-white/5 p-6 rounded-xl border border-white/10">
              <h3 className="text-xl font-semibold mb-3">Multi-Language Support</h3>
              <p className="text-gray-400">
                Generate code across multiple programming languages with expert precision
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}

export default Introduction;